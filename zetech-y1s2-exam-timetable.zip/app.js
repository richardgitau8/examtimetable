const exams = [
  { date: "fri", time: "08:30–10:30", dateLabel: "Friday, 27 November 2026", title: "Engineering Mathematics II", venue: "A006", tone: "tone-red" },
  { date: "fri", time: "11:30–13:30", dateLabel: "Friday, 27 November 2026", title: "Analogue Electronics I", venue: "A006", tone: "tone-gold" },
  { date: "mon", time: "08:30–10:30", dateLabel: "Monday, 30 November 2026", title: "Electrical Installation Technology I", venue: "A006", tone: "tone-crimson" },
  { date: "tue", time: "08:30–10:30", dateLabel: "Tuesday, 1 December 2026", title: "Electrical Engineering Principles I", venue: "L117", tone: "tone-blue" },
  { date: "tue", time: "14:30–16:30", dateLabel: "Tuesday, 1 December 2026", title: "Renewable Energy and Technologies", venue: "A006", tone: "tone-wine" },
  { date: "wed", time: "08:30–10:30", dateLabel: "Wednesday, 2 December 2026", title: "Electrical Instrumentation", venue: "A006", tone: "tone-green" },
  { date: "wed", time: "14:30–16:30", dateLabel: "Wednesday, 2 December 2026", title: "Materials Science and Technology", venue: "A006", tone: "tone-teal" },
];

const slots = ["08:30–10:30", "11:30–13:30", "14:30–16:30"];
const dates = ["fri", "mon", "tue", "wed"];
const body = document.querySelector("#timetable-body");
const dialog = document.querySelector("#exam-dialog");
const closeButton = document.querySelector(".dialog-close");

function renderTimetable() {
  body.replaceChildren();

  for (const time of slots) {
    const row = document.createElement("tr");
    const timeHeading = document.createElement("th");
    timeHeading.scope = "row";
    timeHeading.textContent = time;
    row.append(timeHeading);

    dates.forEach((date, dateIndex) => {
      const cell = document.createElement("td");
      const exam = exams.find((item) => item.date === date && item.time === time);
      if (exam) {
        const card = document.createElement("button");
        card.type = "button";
        card.className = `exam-card ${exam.tone}`;
        card.setAttribute("aria-label", `${exam.title}, ${exam.dateLabel}, ${time}, ${exam.venue}. Show details.`);
        card.style.animationDelay = `${dateIndex * 45}ms`;

        const title = document.createElement("span");
        title.className = "course-title";
        title.textContent = exam.title;
        const venue = document.createElement("span");
        venue.className = "venue";
        venue.textContent = exam.venue;
        card.append(title, venue);
        card.addEventListener("click", () => showExamDetails(exam));
        cell.append(card);
      } else {
        const empty = document.createElement("span");
        empty.className = "empty-slot";
        empty.setAttribute("aria-label", "No examination scheduled");
        empty.textContent = "—";
        cell.append(empty);
      }
      row.append(cell);
    });
    body.append(row);
  }
}

function showExamDetails(exam) {
  document.querySelector("#dialog-title").textContent = exam.title;
  document.querySelector("#dialog-date").textContent = exam.dateLabel;
  document.querySelector("#dialog-time").textContent = exam.time;
  document.querySelector("#dialog-venue").textContent = exam.venue;
  dialog.showModal();
}

closeButton.addEventListener("click", () => dialog.close());
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) dialog.close();
});

renderTimetable();
